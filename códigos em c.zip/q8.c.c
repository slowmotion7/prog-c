// Antonio tem 1,50m e cresce 2cm por ano. Carlos tem 1,10m e cresce 3cm por ano. Fazer um
// programa que calcule quantos anos seriam necess ́arios para que Carlos tivesse a mesma altura que
// Antonio. Supondo que os dois crescem todos os anos.



#include <stdio.h>

int main() {

  float altura_antonio = 1.50;
  float altura_carlos = 1.10;
  float crescimento_antonio = 0.02;
  float crescimento_carlos = 0.03;
  int anos = 0;

  while (altura_carlos < altura_antonio) {
    altura_antonio += crescimento_antonio;
    altura_carlos += crescimento_carlos;
    anos++;
  }

  printf("Serão necessários %d anos para que Carlos tenha a mesma altura que Antonio.\n", anos);

  return 0;
}
