// descrição da questçao Fa̧ca um programa que pe ̧ca um n ́umero (maior que 1) e imprima os n ́umeros de 1 at ́  o n ́umeroinformado. 
//Sendo que, quando chegar na metade da impress ̃ao, mostrar a mensagem Metade (a metaden ̃ao precisa ser exata).





#include <stdio.h>

int main() {
    int numero;

    printf("Digite um número maior que 1: ");
    scanf("%d", &numero);

    if (numero <= 1) {
        printf("Número inválido. Por favor, insira um número maior que 1.\n");
    } else {
        for (int i = 1; i <= numero; i++) {
            printf("%d\n", i);
            if (i == numero / 2) {
                printf("Metade\n");
            }
        }
    }

    return 0;
}
