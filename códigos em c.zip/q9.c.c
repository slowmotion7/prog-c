// Fazer um programa que simule um campeonato com 4 times (A, B, C e D). Sera pedido o nome do
// primeiro time com os gols marcados e o nome do segundo time com os gols marcados. Este processo

// se repetir ́a at ́e que seja informado um valor diferente de A, B, C ou D para o primeiro time. Ao final
// dever ́a ser apresentado o n ́umero de pontos de cada time e o campe ̃ao. Caso houve empate na primeira
// coloca ̧c ̃ao informar que n ̃ao houve campe ̃ao. Calculo dos pontos: vit ́oria 3 pontos, empate 1 ponto e
// derrota 0 ponto. Exemplo:
// Time: A
// Gols: 2
// Time: B
// Gols: 1
// Time: C
// Gols: 2
// Time: A
// Gols: 4
// Time: X ← valor diferente de A, B, C ou D ent ̃ao finaliza
// Campe ̃ao: A
// A: 6 pontos
// B: 0 pontos
// C: 0 pontos
// D: 0 pontos


#include <stdio.h>

int main() {
    char nomesTimes[] = {'A', 'B', 'C', 'D'};
    int pontosTimes[] = {0, 0, 0, 0};

    while (1) {
        char time1, time2;
        int golsTime1, golsTime2;

        printf("Nome do Time: ");
        scanf(" %c", &time1);

        if (time1 < 'A' || time1 > 'D') {
            break;
        }

        printf("Gols marcados pelo time %c: ", time1);
        scanf("%d", &golsTime1);

        printf("Nome do Time: ");
        scanf(" %c", &time2);

        if (time2 < 'A' || time2 > 'D') {
            break;
        }

        printf("Gols marcados pelo time %c: ", time2);
        scanf("%d", &golsTime2);

        int indiceTime1 = time1 - 'A';
        int indiceTime2 = time2 - 'A';

        if (golsTime1 > golsTime2) {
            pontosTimes[indiceTime1] += 3;
        } else if (golsTime1 < golsTime2) {
            pontosTimes[indiceTime2] += 3;
        } else {
            pontosTimes[indiceTime1]++;
            pontosTimes[indiceTime2]++;
        }
    }

    int maiorPontuacao = pontosTimes[0];
    char campeao = 'A';

    for (int i = 1; i < 4; i++) {
        if (pontosTimes[i] > maiorPontuacao) {
            maiorPontuacao = pontosTimes[i];
            campeao = nomesTimes[i];
        }
    }

    printf("Campeão: %c\n", campeao);

    for (int i = 0; i < 4; i++) {
        printf("%c: %d pontos\n", nomesTimes[i], pontosTimes[i]);
    }

    return 0;
}


