//Fa ̧ca um programa que pe ̧ca o sal ́ario e o n ́umero de filhos dos habitantes de uma regi ̃ao. Quando
//o sal ́ario informado for menor que zero, as entradas s ̃ao finalizadas e ser ̃ao apresentadas as m ́edias
//salarial e de filhos informados. Exemplo:
//Sal ́ario: 1500
//Filhos: 2
//Sal ́ario: 3245
//Filhos: 2
//Sal ́ario: -1
//M ́edia sal ́arios: 2372.5
//M ́edia filhos: 2.0



#include <stdio.h>

int main() {
    int habitantes = 0;
    float totalSalario = 0;
    int totalFilhos = 0;

    while (1) {
        printf("Salário (ou qualquer número negativo para encerrar): ");
        float salario;
        scanf("%f", &salario);

        if (salario < 0) {
            break;
        }

        printf("Número de filhos: ");
        int filhos;
        scanf("%d", &filhos);

        habitantes++;
        totalSalario += salario;
        totalFilhos += filhos;
    }

    if (habitantes > 0) {
        float mediaSalario = totalSalario / habitantes;
        float mediaFilhos = (float)totalFilhos / habitantes;

        printf("Média salarial: %.1f\n", mediaSalario);
        printf("Média de filhos: %.1f\n", mediaFilhos);
    } else {
        printf("Nenhum habitante informado\n");
    }

    return 0;
