// Um professor gostaria de ter um programa para calcular a m ́edia final de seus alunos. Para isso ele
// informa a matr ́ıcula e as 10 notas que o alunos teve durante o semestre. Ap ́os informar as 10 notas, o
// programa imprime a mar ́ıcula do aluno e a m ́edia que obteve (m ́edia aritm ́etica simples). Quando o
// professor digitar 0 o programa finaliza e apresenta a m ́edia geral da turma. Proibido colocar 10 input
// para pedir as notas. Exemplo:
// Matr ́ıcula: 22010
// Nota 1: 4
// Nota 2: 6
// Nota 3: 6
// Nota 4: 6
// Nota 5: 8
// Nota 6: 4
// Nota 7: 7
// Nota 8: 8
// Nota 9: 6
// Nota 10: 5
// 22010, m ́edia: 6.0
// Matr ́ıcula: 0
// M ́edia geral da turma: 6.0

#include <stdio.h>

int main() {
    int aluno, nota, total_alunos = 0, soma_notas_turma = 0;

    while (1) {
        printf("Matrícula (digite 0 para encerrar): ");
        scanf("%d", &aluno);

        if (aluno == 0) {
            if (total_alunos == 0) {
                printf("Nenhum aluno inserido. Encerrando o programa.\n");
            } else {
                printf("Média geral da turma: %.1f\n", (float)soma_notas_turma / (total_alunos * 10));
            }
            break;
        }

        total_alunos++;
        int soma_notas_aluno = 0;

        printf("Notas (insira as 10 notas separadas por espaços): ");
        
        for (int i = 0; i < 10; i++) {
            printf("Nota %d: ", i + 1);
            scanf("%d", &nota);
            soma_notas_aluno += nota;
        }

        printf("Aluno: %d, Média: %.1f\n", aluno, (float)soma_notas_aluno / 10);
        soma_notas_turma += soma_notas_aluno;
    }

    return 0;
}