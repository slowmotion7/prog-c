//Fa ̧ca um programa que simule a multiplica ̧c ̃ao atrav ́es de adi ̧c ̃oes. Para tal ser ̃ao pedidos os dois
//operandos. Por exemplo se for informado 3 e 4, dever ́a ser calculado, atrav ́es de soma, 3∗4, ou seja, 12.
//Este c ́alculo  ́e feito somando o primeiro valor informado por ele mesmo o n ́umero de vezes representada
//pelo segundo n ́umero. Nesse exemplo, o trˆes seria somado quatro vezes: 3+3+3+3, resultado 12.



#include <stdio.h>

int main() {
  int num1;
  int num2;

  printf("Digite o primeiro numero: ");
  scanf("%d", &num1);

  printf("Digite o segundo numero: ");
  scanf("%d", &num2);

  int resultado = 0;
  for (int i = 0; i < num2; i++) {
    resultado += num1;
  }

  printf("O resultado da multiplicação é %d.\n", resultado);

  return 0;
}
