//Construa um programa que simule uma calculadora simples. Primeiro  ́e informada a opera ̧c ̃ao
//desejada +, ?, ? ou /, em seguida os dois operandos e apresente o resultado da opera ̧c ̃a
//  ́e finalizado quando a opera ̧c ̃ao desejada for igual `a @.

#include <stdio.h>

int main() {
    char operacao;
    int num1, num2, resultado;

    do {
    
        printf("Digite a operação (+, -, *, / ou @ para sair): ");
        scanf(" %c", &operacao);

//arrumar o comand do @

        if (operacao == '@') {
            printf("Encerrando a calculadora.\n");
            break;
        }

        // Leitura dos operandos
        printf("Digite o primeiro operando: ");
        scanf("%d", &num1);

        printf("Digite o segundo operando: ");
        scanf("%d", &num2);


        if (operacao == '+') {
            resultado = num1 + num2;
        } else if (operacao == '-') {
            resultado = num1 - num2;
        } else if (operacao == '*') {
            resultado = num1 * num2;
        } else if (operacao == '/') {
            resultado = num1 / num2;
        }


        printf("A operação escolhida foi %c e o resultado foi %d.\n", operacao, resultado);

    } while (operacao != '@');

    return 0;
}

// falta arrumar o os if e else não esqucer
