//Fa ̧ca um programa para calcular o fatorial de um n ́umero dado. O fatorial de um n ́umero n  ́e
//n × (n − 1) × (n − 2) × . . . × 1, por defini ̧c ̃ao o fatorial de 0 e 1  ́e 1. Por exemplo, o fatorial de 5  ́e
//120, ou seja, 5 × 4 × 3 × 2 × 1 (perceba que n ̃ao  ́e necess ́ario fazer a  ́ultima multiplica ̧c ̃ao j ́a que 1  ́e o
//elemento neutro da multiplica ̧c ̃ao).

#include <stdio.h>

int main() {
    int num, i = 1, fatorial = 1;

    printf("Digite um número: ");
    scanf("%d", &num);

    while (i <= num) {
        fatorial *= i;
        i++;
    }

    printf("Resultado: %d", fatorial);

    return 0;
}
