//Fa ̧ca um programa que pe ̧ca uma valor e imprima a soma de todos os n ́umeros de 1 at ́e o valor
//informado. Por exemplo, se o valor informado for 6, o resultado ser ́a 21, ou seja, 1 + 2 + 3 + 4 + 5 + 6.



#include <stdio.h>

int main() {
  int vl;

  printf("Digite um valor: ");
  scanf("%d", &vl);

  int soma = 0;
  for (int i = 1; i <= vl; i++) {
    soma += i;
  }

  printf(" o resultado de %d é %d.\n", vl, soma);

  return 0;

  }